package com.cg.salesmanagement.test;


import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.salesmanagement.Exception.ValidProductCategoriesExceptions;
import com.cg.salesmanagement.Exception.ValidProductCodeException;
import com.cg.salesmanagement.Exception.ValidQuantityEnteredException;
import com.cg.salesmanagement.bean.Sale;
import com.cg.salesmanagement.services.ISaleService;
import com.cg.salesmanagement.services.SaleService;
import com.cg.salesmanagement.util.CollectionUtil;


public class TestClass {

    private static ISaleService services;
    @BeforeClass
    public static void setUpTestEnv() {
        services=new SaleService();
    }
    @Before
    public void setUpTestData() {
        Sale sale1=new Sale(21,"TV", "Electronics", LocalDate.now(), 2, 2000, 0);
        Sale sale2=new Sale(11,"Video", "Electronics", LocalDate.now(), 3, 7000, 0);
    }
    
    @Test(expected=ValidProductCodeException.class)
    public void testForInvalidProductId() throws ValidProductCodeException {
        services.validateProductCode(4324);
    }
    @Test
    public void testForValidProductId() throws ValidProductCodeException {
        boolean expected=true;
        boolean actual=services.validateProductCode(1001);
        Assert.assertEquals(expected, actual);
    }
    @Test(expected=ValidProductCategoriesExceptions.class)
    public void testForInvalidProductCategory() throws ValidProductCategoriesExceptions {
        services.validateProductCat("ew");
    }
    @Test(expected=ValidQuantityEnteredException.class)
    public void testForInvalidProductQuantity() throws ValidQuantityEnteredException{
        services.validateQuantity(9);
    }
 
   
    @After
    public void tearDownTestData() {
        CollectionUtil.sales.clear();
    }
    @AfterClass
    public static void tearDownTestEnv() {
        services=null;
    }

}
