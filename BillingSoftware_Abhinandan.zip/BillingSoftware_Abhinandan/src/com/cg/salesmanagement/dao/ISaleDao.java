package com.cg.salesmanagement.dao;

import com.cg.salesmanagement.bean.Sale;

public interface ISaleDao {
	 Sale insertSalesDetails(Sale sale);

	Sale findOne(Sale sale);
	
}