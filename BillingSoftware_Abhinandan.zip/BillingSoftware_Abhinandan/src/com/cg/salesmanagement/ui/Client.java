package com.cg.salesmanagement.ui;



import java.time.LocalDate;
import java.util.Scanner;

import com.cg.salesmanagement.Exception.ValidProductCategoriesExceptions;
import com.cg.salesmanagement.Exception.ValidProductCodeException;
import com.cg.salesmanagement.Exception.ValidProductPriceException;
import com.cg.salesmanagement.Exception.ValidQuantityEnteredException;
import com.cg.salesmanagement.bean.Sale;
import com.cg.salesmanagement.services.ISaleService;
import com.cg.salesmanagement.services.SaleService;


public class Client {

    public static void main(String[] args) {
        ISaleService saleService=new SaleService();
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter product code: ");
        int code=scan.nextInt();
        System.out.println("Enter quanity:");
        int quant=scan.nextInt();
        LocalDate currDate=LocalDate.now();
        Sale sale=new Sale(code, quant);
        sale.setSaleDate(currDate);
        try {
       saleService.insertSalesDetails(sale);
       System.out.println("ID : "+sale.getSaleId());
       System.out.println("Product Category : "+sale.getCategory());
       System.out.println("Product Description : "+sale.getProductName());
       System.out.println("Product Price : "+sale.getPrice());
       System.out.println("Quantity: "+sale.getQuantity());
       System.out.println("Purchase Date:"+sale.getSaleDate());
       System.out.println("Line Total(Rs): "+sale.getLineTotal());
       
}
        catch(ValidProductCategoriesExceptions e) {
            System.out.println("Category should be electronics or toys"); }
        catch(ValidProductPriceException e) {
            System.out.println("Price should be greater than 200"); }
        catch(ValidQuantityEnteredException e) {
            System.out.println("Quantity should be greater than 0 and less than 5"); }
        catch(ValidProductCodeException e) {
            System.out.println("Product code not valid");
        }
    }

}
