package com.cg.salesmanagement.util;

import java.util.HashMap;
import java.util.Random;

import com.cg.salesmanagement.bean.Sale;

public class CollectionUtil {
	public static HashMap<Integer,Sale>sales=new HashMap<Integer, Sale>();
	static int salesId;
	public static int getSalesId()
	{
		salesId=(int) Math.random();
	return salesId;
	}
	public static HashMap<Integer,Sale>getCollection(){
		return sales;
	}
	
	}

