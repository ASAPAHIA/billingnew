package com.cg.salesmanagement.Exception;

public class ValidProductCodeException extends RuntimeException{

	public ValidProductCodeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ValidProductCodeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ValidProductCodeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ValidProductCodeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ValidProductCodeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
