package com.cg.salesmanagement.services;
import java.util.HashMap;

import javax.swing.text.html.InlineView;

import com.cg.salesmanagement.Exception.ValidProductCategoriesExceptions;
import com.cg.salesmanagement.Exception.ValidProductCodeException;
import com.cg.salesmanagement.Exception.ValidProductPriceException;
import com.cg.salesmanagement.Exception.ValidQuantityEnteredException;
import com.cg.salesmanagement.bean.Sale;
import com.cg.salesmanagement.dao.ISaleDao;
import com.cg.salesmanagement.dao.SaleDao;


public class SaleService implements ISaleService {
    ISaleDao saleDao=new SaleDao();
    @Override
    public Sale insertSalesDetails(Sale sale) {
        if(!(validateProductCode(sale.getProdCode()))) {
            throw new ValidProductCodeException("Product code not valid");
        }
        else if(!(validateQuantity(sale.getQuantity())))
            throw new ValidQuantityEnteredException("Invalid quantity");
        else
            sale=saleDao.insertSalesDetails(sale);
        if(!(validateProductCat(sale.getCategory())))
            throw new ValidProductCategoriesExceptions();
        else if(!(validateProductPrice(sale.getPrice())))
            throw new ValidProductPriceException();
        return sale;
    }

    @Override
    public boolean validateProductCode(int productId) {
        if(productId==1001||productId==1002||productId==1003||productId==1004||productId==1005||productId==1006)
            return true;
        else
            return false;
    }

    @Override
    public boolean validateQuantity(int qty) throws  ValidQuantityEnteredException {
        if(qty>0&&qty<5)
            return true;
        else
            return false;
    }

    @Override
    public boolean validateProductCat(String prodCat) {
        if(prodCat.equalsIgnoreCase("electronics")||prodCat.equalsIgnoreCase("toys"))
            return true;
        else
            return false;
    }

    @Override
    public boolean validateProductName(String prodName) {
        return false;
    }

    @Override
    public boolean validateProductPrice(float price) {
        if(price>200)
            return true;
        else
            return false;
    }


}
